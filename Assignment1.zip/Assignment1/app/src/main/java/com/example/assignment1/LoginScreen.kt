package com.example.assignment1

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast

import com.example.assignment1.databinding.LoginScreenBinding


class LoginScreen : Fragment() {
    private lateinit var binding: LoginScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //;
        binding = LoginScreenBinding.inflate(layoutInflater)

        val reg = Regex("^[6-9]\\d{9}\$")
        binding.numberInput.editTextLogin.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // null
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // null
            }

            override fun afterTextChanged(s: Editable?) {
                val number = binding.numberInput.editTextLogin.text.toString()
                if (number.isBlank() || number.length < 10) {
                    binding.numberInput.warning.text = getString(R.string.pleaseEnterMobileNumber)
                } else if (!reg.matches(number)) {
                    binding.numberInput.warning.text = getString(R.string.invalidMobileNumber)

                } else {
                    binding.numberInput.warning.text = null
                }
            }
        })

        binding.continueButtonLogin.setOnClickListener {
            if (binding.numberInput.warning.error == null && binding.numberInput.editTextLogin.text.length == 10 && binding.iAgreeToFollowing.isChecked) {
                val fragment = OtpVerification()
                parentFragmentManager.beginTransaction().replace(R.id.container1, fragment)
                    .addToBackStack(null).commit()
            }

        }







        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.skip.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container1, Dashboard()).commit()
        }

    }
}