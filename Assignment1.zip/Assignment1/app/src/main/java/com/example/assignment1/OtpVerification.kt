package com.example.assignment1

import android.os.Bundle
import android.text.Editable
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.text.TextWatcher
import com.example.assignment1.databinding.FragmentOtpVerificationBinding

class OtpVerification : Fragment() {
    private lateinit var binding: FragmentOtpVerificationBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentOtpVerificationBinding.inflate(layoutInflater)
        // Inflate the layout for this fragment
        setupPinInput()

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        binding.continueButtonLogin.setOnClickListener {
            val inputPin:String = binding.pin1.text.toString() +
                    binding.pin2.text.toString() +
                    binding.pin3.text.toString() +
                    binding.pin4.text.toString() +
                    binding.pin5.text.toString() +
                    binding.pin6.text.toString()
          if(inputPin.trim().length==6){
            val fragment=NumberVerification()
                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.container1, fragment).commit()
            }
            else  binding.errorMsg.text= getString(R.string.please_enter_opt)
        }

    }


    fun setupPinInput() {
        val pinFields = listOf(
            binding.pin1,
            binding.pin2,
            binding.pin3,
            binding.pin4,
            binding.pin5,
            binding.pin6
        )

        for (i in pinFields.indices) {
            pinFields[i].addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                    // No-op
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (s?.length == 1 && i < pinFields.size - 1) {
                        pinFields[i + 1].requestFocus()
                    }
                }

                override fun afterTextChanged(s: Editable?) {

                    // No-op
                }
            })
        }
    }

}